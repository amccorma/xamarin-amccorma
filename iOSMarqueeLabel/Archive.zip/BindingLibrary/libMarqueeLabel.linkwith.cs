using ObjCRuntime;

[assembly: LinkWith ("libMarqueeLabel.a", SmartLink = true, ForceLoad = true)]
