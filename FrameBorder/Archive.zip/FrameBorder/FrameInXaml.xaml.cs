﻿using System;
using System.Collections.Generic;

using Xamarin.Forms;

namespace FrameBorder
{
	public partial class FrameInXaml : ContentPage
	{
		public FrameInXaml ()
		{
			InitializeComponent ();
		}
	}
}

