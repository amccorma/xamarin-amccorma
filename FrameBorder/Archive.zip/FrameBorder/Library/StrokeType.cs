﻿using System;

namespace FrameBorder
{
	public enum StrokeType{
		Solid,

		Dotted,

		Dashed
	}
}

