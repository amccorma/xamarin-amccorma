﻿using System;

namespace MaskedEditAndroid.Mask
{
	public class MaskRules
	{
		public Int16 Start
		{
			get;
			set;
		}
		public Int16 End
		{
			get;
			set;
		}

		public string Mask
		{
			get;
			set;
		}
	}
}

