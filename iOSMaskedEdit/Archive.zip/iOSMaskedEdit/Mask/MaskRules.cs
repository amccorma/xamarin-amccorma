﻿using System;

namespace iOSMaskedEdit
{
	public class MaskRules
	{
		public Int16 Start
		{
			get;
			set;
		}
		public Int16 End
		{
			get;
			set;
		}

		public string Mask
		{
			get;
			set;
		}
	}
}

