﻿using System;
using System.Collections.Generic;
using Xamarin.Forms;
using mobile.models.Controls;
using mobile.models.Overlay;

namespace mobile.pages
{
	public partial class Page1 : BasePage
	{
		public Page1 ()
		{			
			InitializeComponent ();
		}
	}
}

