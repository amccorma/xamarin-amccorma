﻿using Xamarin.Forms;
using mobile.models.Controls;

namespace mobile.pages
{
	public partial class RegionOfficersPage : BasePage
	{
		public RegionOfficersPage ()
		{
			InitializeComponent ();
		}
	}
}

