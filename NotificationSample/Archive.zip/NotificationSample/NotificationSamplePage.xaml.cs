﻿using Xamarin.Forms;

namespace NotificationSample
{
	public partial class NotificationSamplePage : ContentPage
	{
		public NotificationSamplePage()
		{
			InitializeComponent();
		}
	}
}
