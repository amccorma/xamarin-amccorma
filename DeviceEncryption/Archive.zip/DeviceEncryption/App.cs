﻿using System;
using Xamarin.Forms;

namespace DeviceEncryption
{
	public class App : Application
	{
		public App()
		{
			this.MainPage = new TestPage ();
		}
	}
}

