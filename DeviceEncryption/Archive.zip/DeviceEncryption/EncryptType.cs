﻿using System;
namespace DeviceEncryption
{
	public enum EncryptType
	{
		OK,
		STRONG
	}
}


